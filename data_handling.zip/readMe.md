URL for COVID cases data 
https://pomber.github.io/covid19/timeseries.json

URL for country names to codes
https://raw.githubusercontent.com/pomber/covid19/master/docs/countries.json 