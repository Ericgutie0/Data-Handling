#!/bin/python3

import urllib.request
import json

#data from the web
sauce = 'https://raw.githubusercontent.com/pomber/covid19/master/docs/timeseries.json'

#retrive with urllib.requsest
f = urllib.request.urlopen(sauce)

#transfrom into string
content = f.read()
# print(type(content))

#covid_data is the 'content' but a dictionary
covid_data = json.loads(content)


# print(covid_data['US'][-1]['confirmed'])